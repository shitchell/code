  </div>
  <script src="/assets/jquery/js/jquery-1.7.2.min.js"></script>
  <script src="/assets/bootstrap/js/bootstrap.min.js"></script>
 </body>
</html>
